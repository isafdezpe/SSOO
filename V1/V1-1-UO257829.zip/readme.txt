Ejercicios realizados: 0,1,2,3,4,5
Para el ejercicio 5-b, no se ha creado el fichero prog-V1-E5-b, ya que entonces al ejecutar el simulador no daría el error "it does not exist", si no "invalid priority or size"


Mª Isabel Fernández Pérez, UO257829
