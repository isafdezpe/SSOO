Ejercicios realizados: 6,7,8,9,10,11

Ej 6:
El programa de tamaño 65 no se ejecuta por superar el tamaño máximo admitido.



Mª Isabel Fernández Pérez, UO257829
